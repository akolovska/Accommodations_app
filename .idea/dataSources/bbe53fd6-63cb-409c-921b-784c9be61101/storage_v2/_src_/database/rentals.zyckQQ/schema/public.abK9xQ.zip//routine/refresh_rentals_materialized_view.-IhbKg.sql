create procedure refresh_rentals_materialized_view()
    language sql
as
$$
    refresh materialized view concurrently rentals_materialized_view;
$$;

alter procedure refresh_rentals_materialized_view() owner to emc;

