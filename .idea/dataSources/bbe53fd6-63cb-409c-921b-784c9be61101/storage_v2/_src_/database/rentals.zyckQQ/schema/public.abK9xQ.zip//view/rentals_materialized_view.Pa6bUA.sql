create view rentals_materialized_view(id, category, num_rentals, num_rooms, avg_num_rooms) as
SELECT row_number() OVER (ORDER BY category) AS id,
       category,
       count(*)                              AS num_rentals,
       sum(num_rooms)                        AS num_rooms,
       avg(num_rooms)::integer               AS avg_num_rooms
FROM rentals r
GROUP BY category;

alter table rentals_materialized_view
    owner to emc;

