create view rentals_view(id, name, category, num_rooms, host_name, country_name) as
SELECT r.id,
       r.name,
       r.category,
       r.num_rooms,
       (h.name::text || ' '::text) || h.surname::text AS host_name,
       c.name                                         AS country_name
FROM rentals r
         JOIN hosts h ON r.host_id = h.id
         JOIN countries c ON c.id = h.country_id;

alter table rentals_view
    owner to emc;

